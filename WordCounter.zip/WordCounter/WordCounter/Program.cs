using System;
using System.IO;
namespace WordCounter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This program reads the file, and displays the frequency of each word");
            Console.Write("Please, enter file name: ");
            string fileName = Console.ReadLine();
            string[] allWords;
            try
            {
                allWords = File.ReadAllText(fileName).Split(new char[] { ' ', '\t', '\n', '\r' },
                StringSplitOptions.RemoveEmptyEntries);
            }
            catch (Exception)
            {
                Console.WriteLine("File {0} doesn't exist !");
                Console.WriteLine("Quitting the program !");
                Console.ReadKey();
                return;
            }
            string[] words = new string[allWords.Length];
            int[] counts = new int[allWords.Length];
            int count = 0;
            for (int i = 0; i < allWords.Length;i++)
            {
                int index = find(words, count, allWords[i]);
                if (index == -1)
                {
                    words[count] = allWords[i];                          counts[count] = 1; 
                    count++;                 }
                else
                {
                    counts[index]++;                  
                }
            }
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("{0}: {1}",counts[i],words[i]);
            }
            Console.ReadKey();

        }
        static int find(string[] words, int count, string word)
        {
            for (int i = 0; i < count; i++)
                if (words[i] == word) return i;
            return -1;
        }
    }
}
